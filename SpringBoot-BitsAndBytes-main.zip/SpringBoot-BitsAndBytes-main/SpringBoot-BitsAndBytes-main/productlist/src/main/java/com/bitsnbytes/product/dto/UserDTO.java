package com.bitsnbytes.product.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserDTO {

    private String username;
    private String password;

    public String getUsername() {
        return "";
    }

    public Object getPassword() {
        return null;
    }
}
